<?php

class Minion_Exception extends Kohana_Minion_Exception {}
