<?php

class Minion_CLI extends Kohana_Minion_CLI {}
