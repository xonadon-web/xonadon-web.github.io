<?php

abstract class Minion_Task extends Kohana_Minion_Task {}
