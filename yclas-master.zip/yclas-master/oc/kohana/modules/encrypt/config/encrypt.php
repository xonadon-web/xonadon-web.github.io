<?php

return [

	'default' => [
		'type'   => 'openssl',
		'cipher' => 'AES-256-CBC',
	],

];
