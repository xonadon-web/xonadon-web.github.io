<?php

class Auth_ORM extends Kohana_Auth_ORM { }