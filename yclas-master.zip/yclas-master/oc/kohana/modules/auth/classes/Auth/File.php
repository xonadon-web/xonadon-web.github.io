<?php

class Auth_File extends Kohana_Auth_File {}
