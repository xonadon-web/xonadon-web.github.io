<?php

abstract class Model_Database extends Kohana_Model_Database {}
