<?php

class DB extends Kohana_DB {}
