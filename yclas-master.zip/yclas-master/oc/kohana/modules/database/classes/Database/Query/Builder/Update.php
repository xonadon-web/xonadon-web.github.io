<?php

class Database_Query_Builder_Update extends Kohana_Database_Query_Builder_Update {}
