<?php

abstract class Database_Query_Builder_Where extends Kohana_Database_Query_Builder_Where {}
