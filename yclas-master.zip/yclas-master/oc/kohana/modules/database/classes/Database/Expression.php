<?php

class Database_Expression extends Kohana_Database_Expression {}
