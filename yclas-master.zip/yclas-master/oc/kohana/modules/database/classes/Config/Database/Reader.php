<?php

/**
 * Transparent extension of the Kohana_Config_Database_Reader class
 *
 * @package    Kohana/Database
 * @category   Configuration
 * @author     Kohana Team
 * @copyright  (c) Kohana Team
 * @license    https://koseven.ga/LICENSE.md
 */
class Config_Database_Reader extends Kohana_Config_Database_Reader
{
	
}
