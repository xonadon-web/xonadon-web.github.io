<?php

class Cache_Memcache extends Kohana_Cache_Memcache {}