<?php

abstract class Cache extends Kohana_Cache {}