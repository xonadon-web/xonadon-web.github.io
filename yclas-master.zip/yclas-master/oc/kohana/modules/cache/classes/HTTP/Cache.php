<?php

class HTTP_Cache extends Kohana_HTTP_Cache {}